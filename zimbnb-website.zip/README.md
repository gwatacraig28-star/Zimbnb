# ZimBnB Website

This is a **static website** for ZimBnB.

## How to use
1. Upload this repo to GitHub
2. Enable **GitHub Pages**
3. Your site will be live

## Tech
- HTML
- CSS

No backend. No build step.
